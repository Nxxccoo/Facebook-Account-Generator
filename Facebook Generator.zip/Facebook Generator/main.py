from selenium import webdriver
from selenium.webdriver.firefox.service import Service
from selenium.webdriver.firefox.options import Options
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException, TimeoutException
import time
import secrets
import string
import random
from colorama import init, Fore, Style

# Initialize colorama
init(autoreset=True)

def generate_secure_password(length=12):
    """Generate a secure password with letters, digits, and special characters."""
    alphabet = string.ascii_letters + string.digits + string.punctuation
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def generate_random_name():
    """Generate a random first and last name."""
    first_names = ["John", "Jane", "Max", "Emily", "Liam", "Sophia", "Noah", "Olivia", "Lucas", "Ava"]
    last_names = ["Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis", "Martinez", "Rodriguez"]
    firstname = random.choice(first_names)
    lastname = random.choice(last_names)
    return firstname, lastname

def save_account_details(email, password, file_name='Account.txt'):
    """Save the generated email and password to a file."""
    with open(file_name, 'a') as file:
        file.write(f"Email: {email}, Password: {password}\n")
    print(f"{Fore.GREEN}Account details saved to {file_name}")

def create_facebook_account(email):
    firstname, lastname = generate_random_name()
    password = generate_secure_password()

    print(f"{Fore.CYAN}Creating Facebook account for {firstname} {lastname} using email: {email}")

    # Set up Firefox options
    options = Options()
    options.binary_location = r'C:\Program Files\Mozilla Firefox\firefox.exe'  # Update this path if necessary
    service = Service(executable_path=r'C:\Gecko\geckodriver.exe')  # Updated path
    browser = webdriver.Firefox(service=service, options=options)
    
    browser.get("https://facebook.com/reg/")
    time.sleep(2)

    try:
        WebDriverWait(browser, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[text()='Alle Cookies gestatten']"))
        ).click()
    except (NoSuchElementException, TimeoutException) as e:
        print(f"{Fore.YELLOW}Cookies accept button not found or already accepted: {e}")
    
    browser.find_element(By.NAME, "firstname").send_keys(firstname)
    browser.find_element(By.NAME, "lastname").send_keys(lastname)
    browser.find_element(By.NAME, "reg_email__").send_keys(email)
    time.sleep(1)
    browser.find_element(By.NAME, "reg_email_confirmation__").send_keys(email)
    browser.find_element(By.NAME, "reg_passwd__").send_keys(password)

    def select_dropdown(select_element, text=None, value=None, index=None):
        """Try to select an option from a dropdown by text, value, or index."""
        try:
            select = Select(select_element)
            if text:
                select.select_by_visible_text(text)
            elif value:
                select.select_by_value(value)
            elif index is not None:
                select.select_by_index(index)
        except NoSuchElementException as e:
            print(f"{Fore.RED}Could not locate dropdown element: {e}")
            if value:
                browser.execute_script("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('change'));", select_element, value)

    # Select day
    try:
        day_element = WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.ID, "day"))
        )
        select_dropdown(day_element, text="21")
    except TimeoutException as e:
        print(f"{Fore.RED}Day element not found: {e}")

    # Select month
    try:
        month_element = WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.ID, "month"))
        )
        try:
            select_dropdown(month_element, text="June")
        except NoSuchElementException:
            print(f"{Fore.YELLOW}Could not find the text 'June'. Trying to select by value.")
            select_dropdown(month_element, value="6")
    except TimeoutException as e:
        print(f"{Fore.RED}Month element not found: {e}")

    # Select year
    try:
        year_element = WebDriverWait(browser, 10).until(
            EC.presence_of_element_located((By.ID, "year"))
        )
        select_dropdown(year_element, text="1989")
    except TimeoutException as e:
        print(f"{Fore.RED}Year element not found: {e}")

    # Select gender
    try:
        gender_element = WebDriverWait(browser, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//input[@name='sex' and @value='2']"))
        )
        gender_element.click()
    except TimeoutException as e:
        print(f"{Fore.RED}Gender element not found: {e}")

    # Submit
    try:
        submit_button = WebDriverWait(browser, 10).until(
            EC.element_to_be_clickable((By.NAME, "websubmit"))
        )
        submit_button.click()
    except TimeoutException as e:
        print(f"{Fore.RED}Submit button not found: {e}")

    print(f"{Fore.BLUE}Please solve the CAPTCHA if prompted.")

    # Wait for the verification code input
    time.sleep(10)
    
    # Assuming that the verification page has a field with a name or ID that we can target
    try:
        verification_code = input(f"{Fore.CYAN}Enter the verification code you received: ")
        code_input_element = WebDriverWait(browser, 60).until(
            EC.presence_of_element_located((By.NAME, "code"))  # Update this selector as necessary
        )
        code_input_element.send_keys(verification_code)
        browser.find_element(By.NAME, "confirm").click()  # Update this selector as necessary
    except TimeoutException:
        print(f"{Fore.RED}Verification code field not found.")
    except NoSuchElementException:
        print(f"{Fore.RED}Verification process could not be completed automatically.")
    
    browser.quit()

    # Save the account details
    save_account_details(email, password)

    return email, password

# ASCII Art banner for "Facebook Generator"
def print_banner():
    banner = r"""

$$\   $$\ $$$$$$\  $$$$$$\   $$$$$$\   $$$$$$\         $$$$$$\  $$$$$$$$\ $$\   $$\ 
$$$\  $$ |\_$$  _|$$  __$$\ $$  __$$\ $$  __$$\       $$  __$$\ $$  _____|$$$\  $$ |
$$$$\ $$ |  $$ |  $$ /  \__|$$ /  $$ |$$ /  \__|      $$ /  \__|$$ |      $$$$\ $$ |
$$ $$\$$ |  $$ |  $$ |      $$ |  $$ |\$$$$$$\        $$ |$$$$\ $$$$$\    $$ $$\$$ |
$$ \$$$$ |  $$ |  $$ |      $$ |  $$ | \____$$\       $$ |\_$$ |$$  __|   $$ \$$$$ |
$$ |\$$$ |  $$ |  $$ |  $$\ $$ |  $$ |$$\   $$ |      $$ |  $$ |$$ |      $$ |\$$$ |
$$ | \$$ |$$$$$$\ \$$$$$$  | $$$$$$  |\$$$$$$  |      \$$$$$$  |$$$$$$$$\ $$ | \$$ |
\__|  \__|\______| \______/  \______/  \______/        \______/ \________|\__|  \__|
                                                                                    
    """
    print(Fore.CYAN + banner)

# Main program with a menu
print_banner()

print(f"{Fore.CYAN}Facebook made by Nico")
print(f"{Fore.CYAN}Press 1 to start the Facebook Account Generator")

choice = input(f"{Fore.CYAN}Enter your choice: ")

if choice == "1":
    email = input(f"{Fore.CYAN}Bitte geben Sie die E-Mail-Adresse ein, die für den Facebook-Account verwendet werden soll: ")
    email, password = create_facebook_account(email)
    print(f"{Fore.GREEN}Account created with email: {email} and password: {password}")
else:
    print(f"{Fore.RED}Invalid choice. Exiting program.")
